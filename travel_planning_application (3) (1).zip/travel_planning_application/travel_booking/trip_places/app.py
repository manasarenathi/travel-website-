from flask import Flask, render_template, request, redirect, url_for, session, flash,jsonify
import sys
import os
from functools import wraps
import logging
import time
import re

from travel_booking.db.db import Places

# Add the db_module folder to the Python path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../db')))
# Ensure the logs directory exists
log_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'logs')

from db import Places, User, Admin

# Configure logging

# Ensure the logs directory exists
log_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'logs')

# Configure logging with absolute file path
log_file = os.path.join(log_dir, 'admin_signin.log')

app = Flask(__name__, static_url_path='/static')

# Set the secret key
app.secret_key = 'Suresh@1234'

# Rate limiting variables
MAX_ATTEMPTS = 3
ATTEMPT_WINDOW = 300  # 5 minutes
attempts = {}

# Database connection parameters
db_host = "localhost"
db_database = "course_hub"
db_user = "vikas"
db_password = "1234"


@app.route('/', methods=['GET', 'POST'])
def search():
    if request.method == 'POST':
        search_term = request.form.get('search')
        return redirect(url_for('results', search_term=search_term))
    return render_template('index.html')


@app.route('/results', methods=['GET'])
def results():
    search_term = request.args.get('search_term')
    place_instance = Places(db_host, db_database, db_user, db_password)
    places = place_instance.fetch_places(search_term)
    return render_template('search_results.html', courses=places, search_term=search_term)


#using decorators
def verify_credentials(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if request.method == 'POST':
            email = request.form.get('email')
            password = request.form.get('password')
            if email and password:  # Ensure email and password are provided
                user_instance = User(db_host, db_database, db_user, db_password)
                if user_instance.verify_user(email, password):
                    session['user'] = email
                    session['role'] = 'user'
                    return redirect(url_for('home'))
                else:
                    flash('Invalid email, password, or role')
                    return redirect(url_for('signin'))
            else:
                flash('Email and password are required')
                return redirect(url_for('signin'))
        return f(*args, **kwargs)  # Call the original function for GET requests
    return decorated_function

@app.route('/signin', methods=['GET', 'POST'])
@verify_credentials
def signin():
    return render_template('signin.html')


def rate_limited(email):
    now = time.time()
    if email not in attempts:
        attempts[email] = []
    attempts[email] = [timestamp for timestamp in attempts[email] if now - timestamp < ATTEMPT_WINDOW]
    return len(attempts[email]) >= MAX_ATTEMPTS


def valid_email(email):
    regex = '^[a-z0-9]+[\._]?[a-z0-9]+[@]\w+[.]\w+$'
    if re.search(regex, email):
        return True
    else:
        return False

@app.route('/admin_signin', methods=['GET', 'POST'])
def admin_signin():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        if not valid_email(email):
            flash('Invalid email format')
            return redirect(url_for('admin_signin'))

        if rate_limited(email):
            flash('Too many login attempts. Please try again later.')
            return redirect(url_for('admin_signin'))

        admin_instance = Admin(db_host, db_database, db_user, db_password)  # Replace with your Admin class initialization
        if admin_instance.verify_user(email, password):
            session['user'] = email
            session['role'] = 'admin'
            logging.info(f"Successful login for {email} at {time.ctime()}")
            return redirect(url_for('home'))
        else:
            flash('Invalid email or password')
            logging.warning(f"Failed login attempt for {email} at {time.ctime()}")
            return redirect(url_for('admin_signin'))
    return render_template('admin_signin.html')



@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']
        user_instance = User(db_host, db_database, db_user, db_password)
        try:
            print("Adding user: ", name, email)
            user_instance.add_user(name, email, password)
            flash('User registered successfully')
            print("User registered successfully")
            return redirect(url_for('signin'))
        except Exception as e:
            print("Error: ", str(e))
            flash('User registration failed: ' + str(e))
            return redirect(url_for('signup'))
    return render_template('signup.html')




@app.route('/home')
def home():
    if 'user' in session:
        user_email = session['user']
        role = session['role']
        return render_template('index.html', user_email=user_email, role=role)
    return redirect(url_for('signin'))


'''@app.route('/destinations')
def place():
    if 'user' in session:
        user_email = session['user']
        place_instance = Places(db_host, db_database, db_user, db_password)
        places = place_instance.fetch_places()
        return render_template('destinations.html', places=places, user_email=user_email)
    return redirect(url_for('signin'))'''

@app.route('/destinations')
def destinations():
    if 'user' in session:
        place_instance = Places(db_host, db_database, db_user, db_password)
        places = place_instance.fetch_places()
        user_email = session['user']
        return render_template('destinations.html', places=places, user_email=user_email)
    else:
        flash('You need to be logged in to view destinations')
        return redirect(url_for('signin'))



@app.route('/result', methods=['GET'])
def result():
    if 'user' in session:
        user_email = session['user']
        search_term = request.args.get('search_term')
        place_instance = Places(db_host, db_database, db_user, db_password)
        places = place_instance.fetch_places(search_term)
        return render_template('search_result.html', courses=places, search_term=search_term, user_email=user_email)
    return redirect(url_for('signin'))


@app.route('/profile', methods=['GET', 'POST'])
def profile():
    if 'user' not in session:
        return redirect(url_for('signin'))

    user_instance = User(db_host, db_database, db_user, db_password)

    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']
        bio = request.form['bio']
        try:
            user_instance.update_user(session['user'], name, email, password, bio)
            flash('Profile updated successfully')
        except Exception as e:
            flash('Profile update failed: ' + str(e))

    user_data = user_instance.get_user(session['user'])
    return render_template('profile.html', user=user_data)


@app.route('/signout')
def signout():
    session.pop('user', None)
    session.pop('role', None)
    return redirect(url_for('signin'))



#ADD OR REMOVE COURSES

@app.route('/destinations/add', methods=['GET', 'POST'])
def add_place():
    if 'user' in session and session['role'] == 'admin':
        if request.method == 'POST':
            name = request.form['name']
            description = request.form['desc']
            author=request.form['author']
            availability = 'availability' in request.form
            edition=request.form['edition']
            count=request.form['count']

            place_instance = Places(db_host, db_database, db_user, db_password)
            try:
                place_instance.add_place(name, description, author,availability,edition, count)
                flash('Course added successfully')
                return redirect(url_for('course'))
            except Exception as e:
                flash('Failed to add course: ' + str(e))
        return render_template('add_course.html')
    flash('Unauthorized access')
    return redirect(url_for('signin'))

@app.route('/courses/remove/<int:course_id>', methods=['POST'])
def remove_course(course_id):
    if 'user' in session and session['role'] == 'admin':
        course_instance = Course(db_host, db_database, db_user, db_password)
        try:
            course_instance.remove_course(course_id)
            flash('Course removed successfully')
        except Exception as e:
            flash('Failed to remove course: ' + str(e))
    else:
        flash('Unauthorized access')
    return redirect(url_for('course'))


#add the course to the user profile
@app.route('/add_course_to_profile/<int:course_id>', methods=['POST'])
def add_course_to_profile(course_id):
    if 'user' in session:
        user_email = session['user']
        user_instance = User(db_host, db_database, db_user, db_password)
        try:
            user_instance.add_course_to_profile(user_email, course_id)
            flash('Course added to your profile successfully')
        except Exception as e:
            flash('Failed to add course to profile: ' + str(e))
        return redirect(url_for('course'))
    else:
        flash('You need to be logged in to add courses to your profile')
        return redirect(url_for('signin'))

@app.route('/my_destinations', methods=['GET'])
def my_courses():
    if 'user' in session:
        user_email = session['user']
        user_instance = User(db_host, db_database, db_user, db_password)
        courses = user_instance.get_user_courses(user_email)
        return render_template('my_courses.html', courses=courses)
    else:
        flash('You need to be logged in to view your courses')
        return redirect(url_for('signin'))

if __name__ == '__main__':
    app.run(debug=True, port=8080)
